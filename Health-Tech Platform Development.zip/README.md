
  # Health-Tech Platform Development

  This is a code bundle for Health-Tech Platform Development. The original project is available at https://www.figma.com/design/SDqCzS5w1uvmfRyMeJyqWy/Health-Tech-Platform-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  